package alg;

public class MaxAscendingSeq {
    public static void main(String[] args) {
        int[] values = {2, 3, 10, 9, 5, 20};
        getMaxAscendingSeq(values, values.length);
    }

    private static void getMaxAscendingSeq(int[] values, int length) {

    }
}
