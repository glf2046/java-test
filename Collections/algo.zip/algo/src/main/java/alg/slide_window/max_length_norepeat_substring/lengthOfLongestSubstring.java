package alg.slide_window.max_length_norepeat_substring;


import java.util.HashMap;

public class lengthOfLongestSubstring {
    public static void main(String[] args) {
        String s = "abcdd";
        char[] chars = s.toCharArray();
        System.out.println(lengthOfLongestSubstring(chars));
    }

    static int lengthOfLongestSubstring(char[] s) {
        int left = 0, right = 0;
        HashMap<Character, Integer> window = new HashMap<>();
        int res = 0; // 记录最长长度

        while (right < s.length) {
            char c1 = s[right];
            window.put(c1, window.getOrDefault(c1, 0) + 1);
            right++;
            // 如果 window 中出现重复字符
            // 开始移动 left 缩小窗口
            if (window.get(c1) > 1) {
                char c2 = s[left];
                window.put(c2, window.get(c2) - 1);
                left++;
            }
            res = Math.max(res, right - left);
        }
        return res;
    }
}
