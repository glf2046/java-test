package alg;

public class MaxMax2 {
}
