package alg;

public class MaxSumContinousSubArray {

    public static void main(String[] args) {
        int[] a = {-5, 2, 100, -50, 100};
        int max = max(a);
        System.out.println(max);
    }
    private static int max(int[] a){
        int len = a.length;
        if(len <=1){
            return a[0];
        }

        int max = a[0];
        int oldMax = a[0];
        int pos = 0;
        int endPos = 0;

        for (int i = 1; i < len; i++) {
            if(max + a[i] > max) {
                if(max < 0){
                   max = a[i];
                   pos++;
                }else{
                    max = max + a[i];
                }
            }else {
                max = max + a[i];
            }

            if(max > oldMax){
                oldMax = max;
                endPos = i;
            }
        }

        System.out.println("pos: " + pos);
        System.out.println("end pos: " + endPos);

        return oldMax ;

    }
}
