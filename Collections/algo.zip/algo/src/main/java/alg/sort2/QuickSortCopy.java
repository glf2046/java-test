package alg.sort2;

public class QuickSortCopy {
    public static void main(String[] args) {
        int[] a = new int[]{4, 7, 2, 3, 5, 6, 9, 8};
        quick(a, 0, a.length -1);
    }

    private static void quick(int[] a, int low, int high) {
        
    }
}
