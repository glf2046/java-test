package alg.link_list;

/**
 * 反转链表
 * https://leetcode-cn.com/problems/fan-zhuan-lian-biao-lcof/
 */
public class ReverseLinkList {
    public static void main(String[] args) {
        Node head = new Node(1, new Node(2, new Node(3, new Node(4, null))));
        Node newHead = reverse(head);
        Node cursor = newHead;
        while (cursor != null) {
            System.out.println(cursor.value);
            cursor = cursor.next;
        }
    }

    public static Node reverse(Node head) {
        //prev初始的时候最为链表尾巴，所以初始化成null
        Node prev = null;
        Node curr = head;
        while (curr != null){
            Node next = curr.next;
            curr.next = prev;
            //每次处理完一个，prev变成当前的，当前的变成下一个，下一个如果是null就结束了（到了链表尾部）。
            //所以上面有判断 curr != null
            prev = curr;
            curr = next;
        }

        return prev;
    }

    static class Node{
        int value;
        Node next;

        public Node(int value, Node next) {
            this.value = value;
            this.next = next;
        }
    }
}
